import {DatabaseSync} from 'node:sqlite';import {randomBytes,createHash} from 'node:crypto';
export const hash=s=>createHash('sha256').update(s).digest('hex'), secret=()=>randomBytes(32).toString('hex');
export function fail(code,message){throw Object.assign(Error(message),{code})}
const check=(x,c,m)=>{if(!x)fail(c,m)};
const num=(n,min=0,max=1e9)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
export function store(path){const d=new DatabaseSync(path);d.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'customer',balance INTEGER NOT NULL DEFAULT 0 CHECK(balance>=0),blocked INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,uid INTEGER REFERENCES users,expires INTEGER);
CREATE TABLE IF NOT EXISTS keys(id INTEGER PRIMARY KEY,uid INTEGER REFERENCES users,hash TEXT UNIQUE,name TEXT,prefix TEXT,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS inventory(source TEXT PRIMARY KEY,present INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS models(id TEXT PRIMARY KEY,source TEXT UNIQUE,name TEXT,family TEXT,description TEXT,input INTEGER,output INTEGER,maxIn INTEGER,maxOut INTEGER,enabled INTEGER);
CREATE TABLE IF NOT EXISTS requests(uid INTEGER REFERENCES users,id TEXT,fp TEXT,model TEXT,inputrate INTEGER,outputrate INTEGER,maxIn INTEGER,maxOut INTEGER,held INTEGER,state TEXT,input INTEGER,output INTEGER,charge INTEGER,cost INTEGER,costref TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(uid,id));
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY,uid INTEGER REFERENCES users,delta INTEGER,kind TEXT,ref TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(uid,kind,ref));
CREATE TABLE IF NOT EXISTS topups(id TEXT PRIMARY KEY,uid INTEGER REFERENCES users,amount INTEGER,status TEXT DEFAULT 'pending',at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor INTEGER,action TEXT,detail TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
`);const get=(q,...a)=>d.prepare(q).get(...a), all=(q,...a)=>d.prepare(q).all(...a),run=(q,...a)=>d.prepare(q).run(...a);
const tx=f=>{d.exec('BEGIN IMMEDIATE');try{let v=f();d.exec('COMMIT');return v}catch(e){d.exec('ROLLBACK');throw e}};
const record=(actor,action,obj)=>run('INSERT INTO audit(actor,action,detail) VALUES(?,?,?)',actor,action,JSON.stringify(obj));
function credit(uid,delta,kind,ref){check(num(Math.abs(delta),0,1e15),400,'Invalid amount');if(get('SELECT 1 FROM ledger WHERE uid=? AND kind=? AND ref=?',uid,kind,ref))return false;check(run('UPDATE users SET balance=balance+? WHERE id=? AND balance+? BETWEEN 0 AND 1000000000000000',delta,uid,delta).changes,402,'Insufficient balance');run('INSERT INTO ledger(uid,delta,kind,ref) VALUES(?,?,?,?)',uid,delta,kind,ref);return true}
const account=id=>get('SELECT id,email,role,balance,blocked FROM users WHERE id=?',id);
const getModel=id=>get('SELECT m.*,coalesce(i.present,0) present FROM models m LEFT JOIN inventory i USING(source) WHERE m.id=?',id);
function model(m,actor=null){check(/^[a-z0-9][a-z0-9._/-]{0,100}$/.test(m.id)&&typeof m.source==='string'&&m.source.length>0&&m.source.length<=160&&typeof m.name==='string'&&m.name.length>0&&m.name.length<=100&&typeof m.family==='string'&&m.family.length<=48&&typeof m.description==='string'&&m.description.length<=500&&num(m.input)&&num(m.output)&&num(m.maxIn,1,1e6)&&num(m.maxOut,1,32768)&&[0,1].includes(m.enabled),400,'Invalid model settings');return tx(()=>{if(actor!==null&&m.enabled)check(get('SELECT 1 FROM inventory WHERE source=? AND present=1',m.source),400,'Model is not in synced inventory');const prev=getModel(m.id);run(`INSERT INTO models VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET source=excluded.source,name=excluded.name,family=excluded.family,description=excluded.description,input=excluded.input,output=excluded.output,maxIn=excluded.maxIn,maxOut=excluded.maxOut,enabled=excluded.enabled`,m.id,m.source,m.name,m.family,m.description,m.input,m.output,m.maxIn,m.maxOut,m.enabled);record(actor,'model',{before:prev,after:m})})}
function sync(ids,actor=null){check(Array.isArray(ids)&&ids.length>0&&ids.length<=5000&&ids.every(x=>typeof x==='string'&&x.length>0&&x.length<=160),502,'Invalid router inventory');tx(()=>{run('UPDATE inventory SET present=0');for(const id of new Set(ids))run('INSERT INTO inventory VALUES(?,1) ON CONFLICT(source) DO UPDATE SET present=1',id);record(actor,'catalog_sync',{count:new Set(ids).size})});return ids.length}
function reserve(uid,id,fp,expected,maxOut,requirePresent=false,trial=null,inputBudget=null){return tx(()=>{const old=get('SELECT fp,state FROM requests WHERE uid=? AND id=?',uid,id);if(old){check(old.fp===fp,409,'Idempotency key conflicts');return {duplicate:true,state:old.state}}const m=getModel(expected.id);check(m?.enabled&&(!requirePresent||m.present),404,'Model unavailable');check(num(maxOut,1,m.maxOut),400,'Invalid output limit');const inputLimit=inputBudget===null?m.maxIn:inputBudget;check(num(inputLimit,1,1000000),400,'Invalid input budget');const held=m.input*inputLimit+m.output*maxOut;check(account(uid)?.blocked===0,403,'Account disabled');check(!get("SELECT 1 FROM requests WHERE uid=? AND state='pending' LIMIT 1",uid),429,'One request in flight per account');credit(uid,-held,'reserve',id);run('INSERT INTO requests(uid,id,fp,model,inputrate,outputrate,maxIn,maxOut,held,state) VALUES(?,?,?,?,?,?,?,?,?,\'pending\')',uid,id,fp,m.id,m.input,m.output,inputLimit,maxOut,held);return {held,m}})}
function settle(uid,id,input,output,manual=false){return tx(()=>{const r=get('SELECT * FROM requests WHERE uid=? AND id=?',uid,id);if(!r||!['pending',...(manual?['review']:[])].includes(r.state))return false;
const amount=input*r.inputrate+output*r.outputrate;if(!num(input,0,r.maxIn)||!num(output,0,r.maxOut)||!num(amount,0,r.held)){run("UPDATE requests SET state='review' WHERE uid=? AND id=?",uid,id);return null}
credit(uid,r.held-amount,'release',id);run("UPDATE requests SET state='settled',input=?,output=?,charge=? WHERE uid=? AND id=?",input,output,amount,uid,id);return true})}
function review(uid,id){return run("UPDATE requests SET state='review' WHERE uid=? AND id=? AND state='pending'",uid,id).changes===1}
function reject(uid,id){return tx(()=>{const r=get("SELECT held FROM requests WHERE uid=? AND id=? AND state='pending'",uid,id);if(!r)return false;credit(uid,r.held,'release',id);run("UPDATE requests SET state='rejected' WHERE uid=? AND id=?",uid,id);return true})}
d.exec('CREATE TABLE IF NOT EXISTS google_ids(sub TEXT PRIMARY KEY,uid INTEGER NOT NULL UNIQUE REFERENCES users(id))');
return {googleUser:(sub,email,pw)=>tx(()=>{let r=get('SELECT uid FROM google_ids WHERE sub=?',sub);if(r){check(account(r.uid)?.blocked===0,403,'Account disabled');return r.uid}check(!get('SELECT id FROM users WHERE email=?',email),409,'Sign in with your existing method');const uid=Number(run('INSERT INTO users(email,password) VALUES(?,?)',email,pw).lastInsertRowid);run('INSERT INTO google_ids VALUES(?,?)',sub,uid);return uid}),close:()=>d.close(),account,getModel,model,sync,reserve,settle,review,reject,
 user:(email,password,role='customer')=>Number(run('INSERT INTO users(email,password,role) VALUES(?,?,?)',email,password,role).lastInsertRowid),
 login:email=>get('SELECT id,password,blocked FROM users WHERE email=?',email),
 adjust:(uid,delta,ref,actor=null)=>tx(()=>{const old=get("SELECT delta FROM ledger WHERE uid=? AND kind='adjust' AND ref=?",uid,ref);if(old){check(old.delta===delta,409,'Adjustment reference conflicts');return false}credit(uid,delta,'adjust',ref);record(actor,'adjust',{uid,delta,ref});return true}),
 summary:uid=>get(`SELECT count(*) requests,count(CASE WHEN state='settled' THEN 1 END) successes,count(CASE WHEN state IN ('settled','rejected') THEN 1 END) finished,coalesce(sum(input),0) input,coalesce(sum(output),0) output,coalesce(sum(charge),0) spend FROM requests WHERE uid=?`,uid),
 days:uid=>all(`SELECT date(at) day,count(*) n FROM requests WHERE uid=? AND date(at)>=date('now','-29 days') GROUP BY date(at) ORDER BY day`,uid),
 transactions:uid=>all('SELECT kind,delta,at FROM ledger WHERE uid=? ORDER BY id DESC LIMIT 100',uid),
 history:uid=>all('SELECT id,model,state,input,output,charge,at FROM requests WHERE uid=? ORDER BY rowid DESC LIMIT 50',uid),
 catalog:()=>all('SELECT m.id,m.name,m.family,m.description,m.input,m.output,m.maxIn,m.maxOut FROM models m JOIN inventory i USING(source) WHERE m.enabled=1 AND i.present=1 ORDER BY name'),
 inventory:()=>all('SELECT source,present FROM inventory ORDER BY source'),
 users:()=>all('SELECT id,email,role,balance,blocked FROM users ORDER BY id DESC LIMIT 100'),
 session(uid){const t=secret();run('INSERT INTO sessions VALUES(?,?,?)',hash(t),uid,Date.now()+8*3600000);return t},
 sessionUser:t=>get('SELECT u.id,u.role,u.email,u.balance FROM sessions s JOIN users u ON s.uid=u.id WHERE s.hash=? AND s.expires>? AND u.blocked=0',hash(t),Date.now()),
 logout:t=>run('DELETE FROM sessions WHERE hash=?',hash(t)),
 key(uid,name){const t='kar_live_'+secret();run('INSERT INTO keys(uid,hash,name,prefix) VALUES(?,?,?,?)',uid,hash(t),name,t.slice(0,17));return t},
 keyUser:t=>get('SELECT u.id FROM keys k JOIN users u ON k.uid=u.id WHERE k.hash=? AND k.active=1 AND u.blocked=0',hash(t)),
 keys:uid=>all('SELECT id,name,prefix,active FROM keys WHERE uid=?',uid),revoke:(uid,id)=>run('UPDATE keys SET active=0 WHERE uid=? AND id=?',uid,id)
};}
