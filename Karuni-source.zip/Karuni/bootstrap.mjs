import pg from 'pg';import {randomBytes,scryptSync} from 'node:crypto';import fs from 'node:fs';
const pool=new pg.Pool({connectionString:process.env.KARUNI_POSTGRES_URL});const email='owner@karuni.app',password=randomBytes(24).toString('base64url'),salt=randomBytes(32).toString('hex');
const old=await pool.query('SELECT id FROM users WHERE email=$1',[email]);if(old.rowCount)throw Error('Admin already exists; do not reset');
await pool.query('INSERT INTO users(email,password,role) VALUES($1,$2,$3)',[email,salt+':'+scryptSync(password,salt,64).toString('hex'),'admin']);fs.writeFileSync('/root/karuni-admin-handoff.json',JSON.stringify({url:'https://karuni.app/admin',email,password}),{mode:0o600});await pool.end();console.log('Admin provisioned; credential saved privately');
